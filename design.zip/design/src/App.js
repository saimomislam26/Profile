import React from 'react'
import { Routes, Route } from "react-router-dom"
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import './css/style.css'
// import './App.css'
import Box from '@mui/material/Box'
import Container from '@mui/material/Container'
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Home from './Component/Home'
import Sidebar from './Component/Sidebar'
import Feed from './Component/Feed'
import Rightbar from './Component/Rightbar'
import { Stack } from '@mui/material'
import Navbar from './Component/Navbar'


const App = () => {
  return (
    <Box>
      {/* <Routes>
        <Route path='/' element={<Home/>} />
      </Routes> */}
      <Navbar/>
      <Stack direction={'row'} spacing={2} justifyContent='space-between'>
        <Sidebar />
        <Feed />
        <Rightbar />
      </Stack>

    </Box>
  )
}

export default App
