import { AppBar, Avatar, Badge, InputBase, Menu, MenuItem, styled, Toolbar, Typography } from '@mui/material'
import React,{useState} from 'react'

import InstagramIcon from '@mui/icons-material/Instagram';
import MailIcon from '@mui/icons-material/Mail';
import NotificationsIcon from '@mui/icons-material/Notifications';


import saimom from '../images/saimom.jpg'

const StyledToolbar = styled(Toolbar)({
    display: "flex",
    justifyContent: "space-between",

})

const Search = styled('div')(({ theme }) => ({
    backgroundColor: "white",
    padding: "0 10px",
    borderRadius: theme.shape.borderRadius,
    width: "30%"
}))

const Icons = styled('Box')(({ theme }) => ({
    display: "none",
    alignItems: "center",
    gap: '20px',
    [theme.breakpoints.up("sm")]:{
        display:'flex'
    }
}))

const UserBox = styled('Box')(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    gap: '10px',
    [theme.breakpoints.up("sm")]:{
        display:'none'
    }
}))
const Navbar = () => {
    const [open,setopen] = useState(false)
    return (
        <AppBar style={{position: 'sticky'}}>
            <StyledToolbar>
                <Typography variant='h6' sx={{ display: { xs: 'none', sm: 'block' } }}>SELF</Typography>
                <InstagramIcon sx={{ display: { xs: 'block', sm: 'none' } }} />
                <Search><InputBase placeholder='search...' /></Search>
                <Icons>
                    <Badge badgeContent={2} color='error'>
                        <MailIcon />
                    </Badge>
                    <Badge badgeContent={2} color='error'>
                        <NotificationsIcon />
                    </Badge>
                    <Avatar src={saimom} onClick={()=>{setopen(true)}} sx={{cursor:'pointer'}}/>
                </Icons>
                <UserBox onClick={()=>{setopen(true)}} sx={{cursor:'pointer'}}>
                    <Avatar src={saimom} />
                    <Typography>Saimom</Typography>
                </UserBox>
            </StyledToolbar>
            <Menu
              sx={{ mt: '45px' }}
              id="menu-appbar"
              anchorOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              open={open}
              onClose={()=>{setopen(false)}}
            >
              <MenuItem>Profile</MenuItem>
              <MenuItem>Setting</MenuItem>
              <MenuItem>Log Out</MenuItem>
            </Menu>
        </AppBar>
    )
}

export default Navbar